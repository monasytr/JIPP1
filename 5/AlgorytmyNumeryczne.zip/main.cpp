#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>
#include <memory>

#include "AlgorytmyNumeryczne.h"


int main() {

    auto f4x_5 = std::make_unique<FunkcjaLiniowa>(4, 5);

    std::cout << f4x_5->oblicz(5) << '\n';
    CalkaOznaczona calkaOznaczona(std::move(f4x_5));

    calkaOznaczona.ustawPrzedzial(10, 20);
    std::cout << calkaOznaczona.oblicz();


}



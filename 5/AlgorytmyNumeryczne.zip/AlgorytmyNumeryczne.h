//
// Created by P0012872 on 28.03.2018.
//

#ifndef TEMPLATES_ALGORYTMYNUMERYCZNE_H
#define TEMPLATES_ALGORYTMYNUMERYCZNE_H
class Funkcja {
public:
    virtual float oblicz(float x) =0;
};

class FunkcjaLiniowa : public Funkcja {
private:
    float a_, b_;

public:
    FunkcjaLiniowa(float a, float b) : a_(a), b_(b) {}
    float oblicz(float x) override {
       return a_*x + b_;
    }
};

class AlgorytmNumeryczny {
protected:

    std::unique_ptr<Funkcja> funkcja_;
    float epsilon_;

public:
    AlgorytmNumeryczny(std::unique_ptr<Funkcja> funkcja, float epsilon = 0.0001f)
            : funkcja_(std::move(funkcja)),  epsilon_(epsilon) {}

    virtual float oblicz() = 0;
};

class CalkaOznaczona : public AlgorytmNumeryczny {
private:
    float a_,b_;
public:
    CalkaOznaczona(std::unique_ptr<Funkcja> funkcja) : AlgorytmNumeryczny(std::move(funkcja)) {}
    void ustawPrzedzial(float a, float b) { a_ = a; b_ = b;}

    float oblicz() override {
        return a_ * funkcja_->oblicz(a_) +b_;
    }
};

class ShapeContainer {
    std::vector<std::unique_ptr<Shape>> shapes;

    std::vector<Shape*> getGreaterThan(){
        std::vector<Shape*>  graters;

        for (auto & shape : shapes) {
            if ()
            graters.push_back(shape.get());
        }
        return graters;
    }
};

#endif //TEMPLATES_ALGORYTMYNUMERYCZNE_H
